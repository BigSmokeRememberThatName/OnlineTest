﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OnlineTestAdmin
{
    public partial class Form2 : Form
    {
        testBuf buffer = new testBuf();
        Student studentBuffer = new Student();

        public Form2()
        {
            InitializeComponent();
        }

        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "10jWFrXSnFFn30090Vh1kkizURnAnOT8L9E9gSUj",
            BasePath = "https://onlinetest-7a9ca.firebaseio.com/"
        };

        public IFirebaseClient client;



        private void Form2_Load(object sender, EventArgs e)
        {

            try
            {
                client = new FireSharp.FirebaseClient(ifc);
            }
            catch
            {
                MessageBox.Show("ошибка подключения!");
            }
            var res = client.Get(@"_nameTest/");
            testBuf check = res.ResultAs<testBuf>();
            string phrase = check.tests;
            string[] words = phrase.Split(';');

            foreach (var word in words)
            {
                comboBoxTest.Items.Add(word);
            }
            statusLabel.Text = "Выберите тест...";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxName.Items.Clear();
            statusLabel.Text = "Подключение к БД...";
            buffer.selectedTest = comboBoxTest.SelectedItem.ToString();
            if (buffer.selectedTest != "")
            {
                var res = client.Get(@"Students/" + buffer.selectedTest);
                testBuf check = res.ResultAs<testBuf>();
                string phrase = check._nameList;
                string[] words = phrase.Split(';');

                foreach (var word in words)
                {
                    comboBoxName.Items.Add(word);
                }
                statusLabel.Text = "Выберите ученика...";
            }
            else
            {
                statusLabel.Text = "Ошибка...";
                MessageBox.Show("Тест не существует");
            }


        }
        public void syncQuest()
        {
            var res = client.Get("tests/" + buffer.selectedTest + "/" + Convert.ToString(buffer.showQ));
            test check = res.ResultAs<test>();
            buffer.quest = check._question;
            buffer.rightA = check._right;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            statusLabel.Text = "Подготовка отчета...";
            buffer.selectedStudent = comboBoxName.SelectedItem.ToString();
            if (buffer.selectedStudent != "")
            {
                var resCount = client.Get("tests/" + buffer.selectedTest);
                test checkCount = resCount.ResultAs<test>();
                buffer.count = checkCount.count;
                var res = client.Get(@"Students/" + buffer.selectedTest + "/" + buffer.selectedStudent);
                Student check = res.ResultAs<Student>();
                buffer.nameStudentString = check.FullName;
                buffer.anwsersString = check.anwsers;
                buffer.rightAnwersString = Convert.ToString(check.rightAnwsers);
                syncQuest();
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(buffer.quest, buffer.anwsersString[buffer.showQ - 1], buffer.rightA);
                label1.Text = "Кол-во вопросов: " + Convert.ToString(buffer.count);
                label2.Text = "Текущий вопрос: " + Convert.ToString(buffer.showQ);
                label3.Text = "Верных ответов: " + buffer.rightAnwersString + " из " + buffer.count;
                statusLabel.Text = "Отчет готов!";
                prevQButton.Enabled = true;
                nextQButton.Enabled = true;
            }
            else
            {
                statusLabel.Text = "Ошибка...";
                MessageBox.Show("Ученик не существует");
            }
        }

        private void nextQuestion_Click(object sender, EventArgs e)
        {
            if (buffer.showQ < buffer.count)
            {
                nextQButton.Enabled = false;
                nextQButton.Text = "Загрузка вопроса...";
                buffer.showQ++;
                statusLabel.Text = "Подготовка " + Convert.ToString(buffer.showQ) + " вопроса...";
                syncQuest();
                nextQButton.Enabled = true;
                nextQButton.Text = "Следующий вопрос";
                prevQButton.Enabled = true;
                prevQButton.Text = "Предыдущий вопрос";
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(buffer.quest, buffer.anwsersString[buffer.showQ - 1], buffer.rightA);
                label1.Text = "Кол-во вопросов: " + Convert.ToString(buffer.count);
                label2.Text = "Текущий вопрос: " + Convert.ToString(buffer.showQ);
                label3.Text = "Верных ответов: " + buffer.rightAnwersString + " из " + buffer.count;
                statusLabel.Text = "Отчет готов!";
            }
            else
            {
                nextQButton.Text = "Достигнута граница";
                nextQButton.Enabled = false;
            }
        }

        private void prevQButton_Click(object sender, EventArgs e)
        {

            if (buffer.showQ > 1)
            {
                prevQButton.Enabled = false;
                prevQButton.Text = "Загрузка вопроса...";
                buffer.showQ--;
                statusLabel.Text = "Подготовка " + Convert.ToString(buffer.showQ) + " вопроса...";
                syncQuest();
                prevQButton.Enabled = true;
                prevQButton.Text = "Предыдущий вопрос";
                nextQButton.Enabled = true;
                nextQButton.Text = "Следующий вопрос";
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(buffer.quest, buffer.anwsersString[buffer.showQ - 1], buffer.rightA);
                label1.Text = "Кол-во вопросов: " + Convert.ToString(buffer.count);
                label2.Text = "Текущий вопрос: " + Convert.ToString(buffer.showQ);
                label3.Text = "Верных ответов: " + buffer.rightAnwersString + " из " + buffer.count;
                statusLabel.Text = "Отчет готов!";
            }
            else
            {
                prevQButton.Enabled = false;
                prevQButton.Text = "Достигнута граница";
                statusLabel.Text = "Отчет готов!";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
