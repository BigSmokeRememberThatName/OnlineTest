﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OnlineTestAdmin
{
    public partial class Form4 : Form
    {
        testBuf buffer = new testBuf();
        Student studentBuffer = new Student();

        public Form4()
        {
            InitializeComponent();
        }
        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "10jWFrXSnFFn30090Vh1kkizURnAnOT8L9E9gSUj",
            BasePath = "https://onlinetest-7a9ca.firebaseio.com/"
        };

        public IFirebaseClient client;

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Выбран тест: " + buffer.selectedTest, "Подтвердите удаление", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                if (buffer.selectedTest != "")
                {
                    statusLabel.Text = "Удаление...";
                    client.DeleteAsync("tests/" + buffer.selectedTest);
                    var res = client.Get(@"_nameTest/");
                    testBuf check = res.ResultAs<testBuf>();
                    string a = buffer.selectedTest + ";";
                    string text = check.tests;
                    buffer.nameTestListNew = text.Replace(a, "");
                    testList stdList = new testList()
                    {
                        tests = buffer.nameTestListNew,
                    };
                    client.Update(@"_nameTest/", stdList);
                    statusLabel.Text = "Удалено...";
                    MessageBox.Show("Удален успешно");
                }
                else MessageBox.Show("Тест не существует");
            }
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(ifc);
            }
            catch
            {
                MessageBox.Show("ошибка подключения!");
            }
            var res = client.Get(@"_nameTest/");
            testBuf check = res.ResultAs<testBuf>();
            string phrase = check.tests;
            string[] words = phrase.Split(';');

            foreach (var word in words)
            {
                comboBoxTest.Items.Add(word);
                comboBoxDel.Items.Add(word);
            }
            statusLabel.Text = "Выберите тест...";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            buffer.selectedTest = comboBoxTest.SelectedItem.ToString();

        }

        private void comboBoxName_SelectedIndexChanged(object sender, EventArgs e)
        {
            buffer.selectedStudent = comboBoxName.SelectedItem.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Выбран тест и пользователь: " + buffer.selectedTest+"\n"+ buffer.selectedStudent, "Подтвердите удаление", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                if (buffer.selectedTest != "")
                {
                    if (buffer.selectedStudent != "")
                    {
                        statusLabel.Text = "Удаление...";
                        client.DeleteAsync("Students/" + buffer.selectedTest + "/" + buffer.selectedStudent);
                        var res = client.Get("Students/" + buffer.selectedTest);
                        StudentList check = res.ResultAs<StudentList>();
                        string a = buffer.selectedStudent + ";";
                        string text = check._nameList;
                        buffer.nameStudentsListNew = text.Replace(a, "");
                        StudentList stdList = new StudentList()
                        {
                            _nameList = buffer.nameStudentsListNew,
                        };
                        client.Update("Students/" + buffer.selectedTest, stdList);
                        statusLabel.Text = "Удалено...";
                        MessageBox.Show("Удален успешно");
                    }
                    else MessageBox.Show("Тест не существует");
                }
                else MessageBox.Show("Тест не существует");
            }
        }

        private void comboBoxDel_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxName.Items.Clear();
            statusLabel.Text = "Подключение к БД...";
            buffer.selectedTest = comboBoxDel.SelectedItem.ToString();
            if (buffer.selectedTest != "")
            {
                var res = client.Get(@"Students/" + buffer.selectedTest);
                testBuf check = res.ResultAs<testBuf>();
                string phrase = check._nameList;
                string[] words = phrase.Split(';');

                foreach (var word in words)
                {
                    comboBoxName.Items.Add(word);
                }
                statusLabel.Text = "Выберите ученика...";
            }
            else
            {
                statusLabel.Text = "Ошибка...";
                MessageBox.Show("Тест не существует");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Выбран тест: " + buffer.selectedTest, "Подтвердите удаление", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                if (buffer.selectedTest != "")
                {
                        statusLabel.Text = "Удаление...";
                        client.DeleteAsync("Students/" + buffer.selectedTest);
                        statusLabel.Text = "Удалено...";
                        MessageBox.Show("Удален успешно");
                }
                else MessageBox.Show("Тест не существует");
            }
            else MessageBox.Show("Тест не существует");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
