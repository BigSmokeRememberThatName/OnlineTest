﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OnlineTestAdmin
{
    public partial class Form3 : Form
    {
        testBuf buffer = new testBuf();
        
        string filePath = string.Empty;
        public Form3()
        {
            InitializeComponent();
           
        }

        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "10jWFrXSnFFn30090Vh1kkizURnAnOT8L9E9gSUj",
            BasePath = "https://onlinetest-7a9ca.firebaseio.com/"
        };

        public IFirebaseClient client;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            statusLabel.Text = "Выберите файл теста";
        }

        private void comfirmButton_Click(object sender, EventArgs e)
        {
            if (testName.Text != "")
            {
                if (filePath != "")
                {
                    if (testCountBox.Text != "")
                    {
                        statusLabel.Text = "Загрузка теста...";
                        label5.Visible = true;
                        progressBar1.Maximum = Convert.ToInt32(testCountBox.Text);
                        var res = client.Get(@"_nameTest/");
                        testList check = res.ResultAs<testList>();
                        buffer.nameTestListNew = check.tests + testName.Text + ";";
                        testList stdList = new testList()
                        {
                            tests = buffer.nameTestListNew,
                        };
                        client.Update(@"_nameTest/", stdList);
                        string line;
                        System.IO.StreamReader file = new System.IO.StreamReader(filePath);
                        for (int i = 0; i < Convert.ToInt32(testCountBox.Text); i++)
                        {
                            line = file.ReadLine();
                            buffer._question = line;
                            line = file.ReadLine();
                            buffer.first = line;
                            line = file.ReadLine();
                            buffer.second = line;
                            line = file.ReadLine();
                            buffer.third = line;
                            line = file.ReadLine();
                            buffer.fourth = line;
                            line = file.ReadLine();
                            buffer.right = line;
                            //MessageBox.Show(buffer._question + "\n" + buffer.first + "\n" + buffer.second + "\n" + buffer.third + "\n" + buffer.fourth + "\n" + buffer.right);
                            testUpload uploadTest = new testUpload()
                            {
                                _question = buffer._question,
                                first = buffer.first,
                                second = buffer.second,
                                third = buffer.third,
                                fourth = buffer.fourth,
                                _right = Convert.ToInt32(buffer.right)
                            };
                            int count = i;
                            count++;
                            client.Update("tests/" + testName.Text + "/" + count, uploadTest);
                            progressBar1.Value = count;
                            label5.Text = "Загружено " + count + " из " + testCountBox.Text;
                        }
                        testCount countUpload = new testCount()
                        {
                            count = Convert.ToInt32(testCountBox.Text)
                        };
                        client.Update("tests/" + testName.Text, countUpload);
                        statusLabel.Text = "Тест загружен";
                        MessageBox.Show("Успешно загружено");
                    }

                    else MessageBox.Show("Введите количество вопросов");
                }
                else MessageBox.Show("Выберите файл с тестом");
            }
            else MessageBox.Show("Введите имя теста");

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(ifc);
            }
            catch
            {
                MessageBox.Show("ошибка подключения!");
            }
        }

        private void openFile_Click(object sender, EventArgs e)
        {
            statusLabel.Text = "Введите кол-во вопросов";
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath = openFileDialog.FileName;
                }
            }
            if (filePath != "")
            {
                openFile.Text = "Файл выбран";
            }
            else openFile.Text = "Файл не выбран";
        }

        private void testCountBox_TextChanged(object sender, EventArgs e)
        {
            statusLabel.Text = "Нажмите Загрузить тест";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Файл должен содержать следующую структуру:\n\nСодержание превого вопроса\nПервый вариант ответа\nВторой вариант ответа\nТретий вариант ответа\nЧетвертый вариант ответа\nПравильный ответ ЦИФРОЙ(Например, 2)\nСодержание второго вопроса\n...\n\nПомните, пустых строк в файле быть НЕ ДОЛЖНО!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f = new Form1();
            f.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
