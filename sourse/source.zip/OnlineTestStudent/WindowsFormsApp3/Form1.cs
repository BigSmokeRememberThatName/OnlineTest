﻿using FireSharp.Config;
using FireSharp.Interfaces;
using System;
using System.Windows.Forms;

namespace WindowsFormsApp3
{

    public partial class Form1 : Form
    {

        testBuf buffer = new testBuf();

        public Form1()
        {
            InitializeComponent();
        }

        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "10jWFrXSnFFn30090Vh1kkizURnAnOT8L9E9gSUj",
            BasePath = "https://onlinetest-7a9ca.firebaseio.com/"
        };

        public IFirebaseClient client;



        private void Form1_Load(object sender, EventArgs e)
        {
            if (Internet.CheckConnection())
                statusLabel.Text = "Подключение к БД успешно";
            else
            {
                MessageBox.Show("Соединение с интернетом не найдено!\nПроверьте подключение");
                Application.Exit();
            }
            comboBox1.Items.Clear();
            try
            {
                client = new FireSharp.FirebaseClient(ifc);
            }
            catch
            {
                MessageBox.Show("ошибка подключения!");
            }
            var res = client.Get(@"_nameTest/");
            testBuf check = res.ResultAs<testBuf>();
            buffer.nameTest = check.tests;
            string phrase = buffer.nameTest;
            string[] words = phrase.Split(';');

            foreach (var word in words)
            {
                comboBox1.Items.Add(word);
            }


        }
        public void syncQuest()
        {
            var res = client.Get(@"tests/" + buffer.selectedTest + "/" + Convert.ToString(buffer.showQ));
            test check = res.ResultAs<test>();
            questionLabel.Text = check._question;
            radioButton1.Text = check.first;
            radioButton2.Text = check.second;
            radioButton3.Text = check.third;
            radioButton4.Text = check.fourth;
            buffer.right = check._right;
        }
        public void parseAnwsers()
        {
            if (radioButton1.Checked == true)
            {
                buffer.anwser = 1;
                buffer.array[buffer.showQ - 1] = buffer.anwser;
                if (buffer.anwser == buffer.right)
                {
                    buffer.trueAnwser++;
                }
            }

            if (radioButton2.Checked == true)
            {
                buffer.anwser = 2;
                buffer.array[buffer.showQ - 1] = buffer.anwser;
                if (buffer.anwser == buffer.right)
                {
                    buffer.trueAnwser++;
                }
            }

            if (radioButton3.Checked == true)
            {
                buffer.anwser = 3;
                buffer.array[buffer.showQ - 1] = buffer.anwser;
                if (buffer.anwser == buffer.right)
                {
                    buffer.trueAnwser++;
                }
            }

            if (radioButton4.Checked == true)
            {
                buffer.anwser = 4;
                buffer.array[buffer.showQ - 1] = buffer.anwser;
                if (buffer.anwser == buffer.right)
                {
                    buffer.trueAnwser++;
                }
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            parseAnwsers();
            if (buffer.showQ < buffer.count)
            {
                nextQButton.Enabled = false;
                nextQButton.Text = "Загрузка вопроса...";
                buffer.showQ++;
                label3.Text = "Текущий вопрос: \n" + Convert.ToString(buffer.showQ);
                syncQuest();
                nextQButton.Enabled = true;
                nextQButton.Text = "Принять";
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
            }
            if (buffer.showQ == buffer.count)
            {
                dialogBtn.Visible = true;
            }
        }

        private void ctrlTest_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Выберите тест")
            {
                MessageBox.Show("Тест не выбран!");
            }
            else
            {
                if (buffer.selectedTest != "")
                {
                    statusLabel.Text = "Тест запущен";
                    comboBox1.Visible = false;
                    ctrlTest.Text = "Синхронизация...";
                    syncQuest();
                    var res = client.Get(@"tests/" + buffer.selectedTest);
                    test check = res.ResultAs<test>();
                    buffer.count = check.count;
                    nextQButton.Enabled = true;
                    ctrlTest.Visible = false;
                    label2.Visible = true;
                    label2.Text = "Кол-во вопросов: \n" + Convert.ToString(buffer.count);
                    label3.Visible = true;
                    label3.Text = "Текущий вопрос: \n" + Convert.ToString(buffer.showQ);
                    radioButton1.Enabled = true;
                    radioButton2.Enabled = true;
                    radioButton3.Enabled = true;
                    radioButton4.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Тест не существует");
                }
            }
        }




        private void button2_Click_1(object sender, EventArgs e)
        {
            if (nameBox.Text != "")
            {
                statusLabel.Text = "Сохранение";
                saveBtn.Text = "Сохранение";
                buffer.doneAnwser = "";
                for (int i = 0; i < buffer.count; i++)
                {
                    buffer.doneAnwser = buffer.doneAnwser + Convert.ToString(buffer.array[i]);
                }

                Student std = new Student()
                {
                    FullName = nameBox.Text,
                    anwsers = buffer.doneAnwser,
                    rightAnwsers = Convert.ToString(buffer.trueAnwser)
                };

                client.Update(@"Students/" + buffer.selectedTest + "/" + nameBox.Text, std);

                var res = client.Get(@"Students/" + buffer.selectedTest);
                StudentList check = res.ResultAs<StudentList>();
                buffer.nameStudentsListNew = check._nameList + nameBox.Text + ";";
                StudentList stdList = new StudentList()
                {
                    _nameList = buffer.nameStudentsListNew,
                };
                string query = (@"Students/" + buffer.selectedTest);
                client.Update(query, stdList);
                this.Height = 375;
                statusLabel.Text = "Тестирование завершено";
                MessageBox.Show("Результаты сохранены.\nВерных ответов: " + buffer.trueAnwser + " из " + buffer.count, "Успех");
                saveBtn.Enabled = false;
                saveBtn.Text = "Сохранено";
                exitButon.Visible = true;
            }
            else
                MessageBox.Show("Введите ФИО!", "Ошибка!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            parseAnwsers();
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
            radioButton4.Enabled = false;
            nextQButton.Enabled = false;
            dialogBtn.Enabled = false;
            this.Height = 440;
            statusLabel.Text = "Введите ФИО";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            buffer.selectedTest = (comboBox1.SelectedItem.ToString());
            statusLabel.Text = "Нажмите Начать тест";
        }

        private void questionLabel_Click(object sender, EventArgs e)
        {
        }

        private void exitButon_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
