﻿using System;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace WindowsFormsApp3
{
    public static class Internet
    {
        [DllImport("wininet.dll")]
        static extern bool InternetGetConnectedState(ref InternetConnectionState lpdwFlags, int dwReserved);

        [Flags]
        enum InternetConnectionState : int
        {
            INTERNET_CONNECTION_MODEM = 0x1,
            INTERNET_CONNECTION_LAN = 0x2,
            INTERNET_CONNECTION_PROXY = 0x4,
            INTERNET_RAS_INSTALLED = 0x10,
            INTERNET_CONNECTION_OFFLINE = 0x20,
            INTERNET_CONNECTION_CONFIGURED = 0x40
        }

        static object _syncObj = new object();

        /// <summary>
        /// Проверить, есть ли соединение с интернетом
        /// </summary>
        /// <returns></returns>
        public static Boolean CheckConnection()
        {
            lock (_syncObj)
            {
                try
                {
                    InternetConnectionState flags = InternetConnectionState.INTERNET_CONNECTION_CONFIGURED | 0;
                    bool checkStatus = InternetGetConnectedState(ref flags, 0);

                    if (checkStatus)
                        return PingServer(new string[]
                                            {
                                                @"google.com",
                                                @"microsoft.com",
                                                @"ibm.com"
                                            });

                    return checkStatus;
                }
                catch
                {
                    return false;
                }
            }
        }


        /// <summary>
        /// Пингует сервера, при первом получении ответа от любого сервера возвращает true 
        /// </summary>
        /// <param name="serverList">Список серверов</param>
        /// <returns></returns>
        public static bool PingServer(string[] serverList)
        {
            bool haveAnInternetConnection = false;
            Ping ping = new Ping();
            for (int i = 0; i < serverList.Length; i++)
            {
                PingReply pingReply = ping.Send(serverList[i]);
                haveAnInternetConnection = (pingReply.Status == IPStatus.Success);
                if (haveAnInternetConnection)
                    break;
            }

            return haveAnInternetConnection;
        }
    }
    class test
    {
        public string _question { get; set; }
        public int _right { get; set; }
        public int count { get; set; }
        public string first { get; set; }
        public string second { get; set; }
        public string third { get; set; }
        public string fourth { get; set; }


    }
    class Student
    {
        public string FullName { get; set; }
        public string anwsers { get; set; }
        public string rightAnwsers { get; set; }

    }
    class StudentList
    {
        public string _nameList { get; set; }
    }
    class testBuf
    {
        public int right;
        public int count;
        public int showQ = 1;
        public int anwser;
        public string doneAnwser;
        public int trueAnwser = 0;
        public int[] array = new int[100];
        public string selectedTest = "";
        public string tests { get; set; }

        public string nameStudentsListNew = "";
        public string nameTest = "";
        public string[] nameTestArray = new string[1000];
    }
}
